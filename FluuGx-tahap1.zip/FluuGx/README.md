# Fluu Gx - Tahap 1 (Floating Panel, UI, Izin)

## Build
1. Unggah folder ini ke repo GitHub (branch main). Workflow `.github/workflows/build.yml` berjalan otomatis atau lewat Actions > Run workflow.
2. Unduh artifact `FluuGx-debug-apk`, instal di HP (izinkan sumber tidak dikenal).
Atau buka di Android Studio (Hedgehog+) lalu Run / Build APK.

## Mengaktifkan izin
1. Buka Fluu Gx > Home > nyalakan Panel Melayang > Lanjut ke pengaturan > aktifkan "Tampilkan di atas aplikasi lain".
2. Kembali ke aplikasi, nyalakan lagi Panel Melayang. Izinkan notifikasi (Android 13+).
3. Gagang hitam tipis muncul di tepi layar: geser ke dalam atau ketuk untuk membuka panel; seret vertikal untuk memindahkan.

## Belum ada di tahap ini
Supabase + Edge Functions + SQL, screenshot, tema Premium.
Premium tetap terkunci (tahap 2).
