(function(){
"use strict";
var A=window.Android,S={},apps=[],pendingPick=[];
function $(id){return document.getElementById(id)}
function state(){try{S=JSON.parse(A.getState())}catch(e){S={slots:[]}}}
function mb(b){return (b/1048576).toFixed(1).replace(".",",")+" MB"}
function setTg(id,on){$(id).classList.toggle("on",!!on)}
function pill(id,ok,t,f){var e=$(id);e.textContent=ok?t:f;e.classList.toggle("ok",ok)}

function render(){
  state();
  document.body.classList.toggle("noanim",!S.anim);
  setTg("tgPanel",S.panel);setTg("sPanel",S.panel);setTg("sRight",S.right);
  setTg("sVib",S.vibrate);setTg("sAnim",S.anim);setTg("sGame",S.gaming);
  pill("stOverlay",S.overlay,"Aktif","Belum aktif");
  pill("stNotif",S.notif,"Aktif","Belum aktif");
  pill("stSvc",S.running,"Berjalan","Mati");
  pill("sPrem",S.premium,"Premium","Free");
  $("ver").textContent="Versi "+(S.version||"");
  $("cacheSize").textContent=mb(A.cacheBytes());
  renderSlots();
}

function renderSlots(){
  var row=$("slotRow");row.innerHTML="";
  (S.slots||[]).forEach(function(s,i){
    var d=document.createElement("button");d.className="slot pop";d.style.animationDelay=(i*40)+"ms";
    d.innerHTML='<img alt="">';d.firstChild.src=s.icon;d.setAttribute("aria-label",s.label);
    d.onclick=function(){slotMenu(i)};row.appendChild(d);
  });
  if((S.slots||[]).length<S.maxSlots){
    var a=document.createElement("button");a.className="slot add pop";a.textContent="+";
    a.setAttribute("aria-label","Tambah aplikasi");a.onclick=openPicker;row.appendChild(a);
  }
  $("slotHint").textContent=(S.slots||[]).length+" dari "+S.maxSlots+" slot terisi. Ketuk ikon untuk mengatur.";
}

function modal(html){$("sheet").innerHTML=html;$("mdl").classList.add("show")}
function closeModal(){$("mdl").classList.remove("show")}
$("mdl").onclick=function(e){if(e.target===this)closeModal()};

function slotMenu(i){
  var s=S.slots[i];
  modal('<div class="label sm">'+esc(s.label)+'</div>'+
   '<button class="btn" data-a="l">Geser ke atas</button><button class="btn" data-a="r">Geser ke bawah</button>'+
   '<button class="btn" data-a="w">Jendela mengambang</button><button class="btn" data-a="d">Hapus</button>');
  $("sheet").onclick=function(e){
    var a=e.target.getAttribute&&e.target.getAttribute("data-a");if(!a)return;
    var p=S.slots.map(function(x){return x.pkg});
    if(a==="l"&&i>0){var t=p[i];p[i]=p[i-1];p[i-1]=t}
    if(a==="r"&&i<p.length-1){var t2=p[i];p[i]=p[i+1];p[i+1]=t2}
    if(a==="d")p.splice(i,1);
    if(a==="w"){var r=A.openFloating(s.pkg);closeModal();
      if(r==="PREMIUM")toast("Jendela mengambang adalah fitur Premium.");
      else if(r!=="OK")toast(r);return}
    A.setSlots(JSON.stringify(p));closeModal();render();
  };
}

function openPicker(){
  pendingPick=(S.slots||[]).map(function(x){return x.pkg});
  modal('<div class="label sm">Pilih aplikasi</div><div id="appList" class="plain">Memuat...</div>'+
        '<button class="btn" id="pickOk">Simpan</button>');
  $("sheet").onclick=null;$("pickOk").onclick=function(){
    A.setSlots(JSON.stringify(pendingPick.slice(0,S.maxSlots)));closeModal();render()};
  A.loadApps();
}
window.openPicker=openPicker;
window.onApps=function(json){
  apps=JSON.parse(json);var box=$("appList");if(!box)return;box.innerHTML="";
  apps.forEach(function(a){
    var d=document.createElement("div");d.className="app"+(pendingPick.indexOf(a.pkg)>-1?" sel":"");
    d.innerHTML='<img alt=""><span></span>';d.firstChild.src=a.icon;d.lastChild.textContent=a.label;
    d.onclick=function(){
      var k=pendingPick.indexOf(a.pkg);
      if(k>-1){pendingPick.splice(k,1);d.classList.remove("sel")}
      else if(pendingPick.length<S.maxSlots){pendingPick.push(a.pkg);d.classList.add("sel")}
      else toast("Slot penuh ("+S.maxSlots+").");
    };
    box.appendChild(d);
  });
};

function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
function toast(t){$("cleanMsg").textContent=t;$("premMsg").textContent=t}

function panelToggle(){
  var want=!S.panel,r=A.setPanel(want);
  if(r==="NEED_OVERLAY"){
    modal('<div class="label sm">Izin diperlukan</div>'+
      '<p class="plain">Panel Melayang perlu izin "Tampilkan di atas aplikasi lain" agar panel bisa muncul di atas game. Izin tidak diaktifkan otomatis. Anda akan diarahkan ke pengaturan Android untuk memberi izin.</p>'+
      '<button class="btn" id="goOv">Lanjut ke pengaturan</button><button class="btn" id="noOv">Batal</button>');
    $("sheet").onclick=null;
    $("goOv").onclick=function(){closeModal();A.requestOverlay()};
    $("noOv").onclick=closeModal;
    return;
  }
  setTimeout(render,250);
}
$("tgPanel").onclick=panelToggle;$("sPanel").onclick=panelToggle;
[["sRight","right"],["sVib","vibrate"],["sAnim","anim"],["sGame","gaming"]].forEach(function(p){
  $(p[0]).onclick=function(){A.setSetting(p[1],!S[p[1]]);render()};
});

$("btnClean").onclick=function(){
  var b=$("btnClean");b.disabled=true;$("cleanMsg").textContent="Membersihkan...";
  setTimeout(function(){
    var r=A.clean();b.disabled=false;
    $("cleanMsg").textContent=r<0?"Gagal membersihkan. Buka pengaturan penyimpanan Android untuk membersihkan manual."
      :"Berhasil. "+mb(r)+" dibersihkan (hanya cache Fluu Gx).";
    if(r<0){modal('<p class="plain">Gagal membersihkan cache.</p><button class="btn" id="stg">Buka pengaturan penyimpanan</button>');
      $("sheet").onclick=null;$("stg").onclick=function(){closeModal();A.openStorageSettings()}}
    render();
  },S.anim?500:0);
};
$("btnOverlay").onclick=function(){A.requestOverlay()};
$("btnNotif").onclick=function(){A.requestNotif()};
$("btnPerm").onclick=function(){A.openAppSettings()};

// Tahap 2: verifikasi kode dilakukan di server Supabase. Tidak ada aktivasi lokal.
$("btnRedeem").onclick=function(){
  var c=$("code").value.trim().toUpperCase();
  if(!/^FLUUGX-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(c)){$("premMsg").textContent="Kode aktivasi tidak valid.";return}
  $("premMsg").textContent="Verifikasi server belum dipasang di versi ini (tahap 2). Premium belum aktif.";
};

var pages=["home","toko","aman","set"];
function go(p){
  pages.forEach(function(x){$("p-"+x).classList.toggle("active",x===p)});
  document.querySelectorAll("#nav button").forEach(function(b){b.classList.toggle("on",b.getAttribute("data-p")===p)});
  $("pages").scrollTop=0;render();
}
document.querySelectorAll("#nav button").forEach(function(b){b.onclick=function(){go(b.getAttribute("data-p"))}});
window.refresh=render;
window.onBack=function(){
  if($("mdl").classList.contains("show")){closeModal();return true}
  if(!$("p-home").classList.contains("active")){go("home");return true}
  return false;
};
render();
})();
