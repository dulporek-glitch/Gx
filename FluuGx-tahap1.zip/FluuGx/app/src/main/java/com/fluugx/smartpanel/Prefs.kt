package com.fluugx.smartpanel

import android.content.Context
import org.json.JSONArray

/** Penyimpanan pengaturan lokal. Status Premium BUKAN diset dari sini oleh UI (lihat tahap 2). */
class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("fluugx", Context.MODE_PRIVATE)

    var panelEnabled: Boolean
        get() = sp.getBoolean("panel", false)
        set(v) = sp.edit().putBoolean("panel", v).apply()
    var sideRight: Boolean
        get() = sp.getBoolean("side_right", false)
        set(v) = sp.edit().putBoolean("side_right", v).apply()
    var vibrate: Boolean
        get() = sp.getBoolean("vibrate", true)
        set(v) = sp.edit().putBoolean("vibrate", v).apply()
    var animations: Boolean
        get() = sp.getBoolean("anim", true)
        set(v) = sp.edit().putBoolean("anim", v).apply()
    var gaming: Boolean
        get() = sp.getBoolean("gaming", false)
        set(v) = sp.edit().putBoolean("gaming", v).apply()
    var panelY: Int
        get() = sp.getInt("panel_y", 400)
        set(v) = sp.edit().putInt("panel_y", v).apply()

    /** Tahap 2: nilai ini hanya boleh ditulis oleh PremiumRepository setelah server Supabase memverifikasi. */
    var premium: Boolean
        get() = sp.getBoolean("premium_verified", false)
        set(v) = sp.edit().putBoolean("premium_verified", v).apply()

    val maxSlots: Int get() = if (premium) 8 else 5

    var slots: List<String>
        get() {
            val arr = JSONArray(sp.getString("slots", "[]"))
            return List(arr.length()) { arr.getString(it) }
        }
        set(v) {
            val arr = JSONArray()
            v.take(maxSlots).forEach { arr.put(it) }
            sp.edit().putString("slots", arr.toString()).apply()
        }
}
