package com.fluugx.smartpanel

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

object AppRepo {
    fun launchable(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != ctx.packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
    }

    fun icon(ctx: Context, pkg: String): Drawable? =
        try { ctx.packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null }

    fun label(ctx: Context, pkg: String): String =
        try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }

    fun iconBase64(ctx: Context, pkg: String, size: Int = 72): String {
        val d = icon(ctx, pkg) ?: return ""
        val bmp = if (d is BitmapDrawable && d.bitmap.width <= size * 2) d.bitmap
        else {
            val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val c = Canvas(b); d.setBounds(0, 0, size, size); d.draw(c); b
        }
        val out = ByteArrayOutputStream()
        Bitmap.createScaledBitmap(bmp, size, size, true).compress(Bitmap.CompressFormat.PNG, 90, out)
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    fun installedJson(ctx: Context): String {
        val arr = JSONArray()
        launchable(ctx).forEach { (p, l) ->
            arr.put(JSONObject().put("pkg", p).put("label", l).put("icon", iconBase64(ctx, p, 56)))
        }
        return arr.toString()
    }

    fun isInstalled(ctx: Context, pkg: String): Boolean =
        ctx.packageManager.getLaunchIntentForPackage(pkg) != null
}
