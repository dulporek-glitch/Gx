package com.fluugx.smartpanel

import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread

/** Jembatan JS -> Kotlin. Hanya dimuat untuk halaman lokal (file:///android_asset). */
class Bridge(private val a: MainActivity) {
    private val prefs = Prefs(a)

    @JavascriptInterface
    fun getState(): String {
        val slots = JSONArray()
        prefs.slots.forEach { p ->
            if (AppRepo.isInstalled(a, p)) slots.put(
                JSONObject().put("pkg", p).put("label", AppRepo.label(a, p)).put("icon", AppRepo.iconBase64(a, p, 96))
            )
        }
        return JSONObject()
            .put("panel", prefs.panelEnabled && FloatingPanelService.running)
            .put("right", prefs.sideRight)
            .put("vibrate", prefs.vibrate)
            .put("anim", prefs.animations)
            .put("gaming", prefs.gaming)
            .put("premium", prefs.premium)
            .put("maxSlots", prefs.maxSlots)
            .put("overlay", a.hasOverlay())
            .put("notif", a.hasNotif())
            .put("running", FloatingPanelService.running)
            .put("version", BuildConfigInfo.version(a))
            .put("slots", slots)
            .toString()
    }

    @JavascriptInterface
    fun setSetting(key: String, value: Boolean) {
        when (key) {
            "right" -> prefs.sideRight = value
            "vibrate" -> prefs.vibrate = value
            "anim" -> prefs.animations = value
            "gaming" -> prefs.gaming = value
        }
        FloatingPanelService.refresh(a)
    }

    /** Mengembalikan "OK", "NEED_OVERLAY", atau "OFF". */
    @JavascriptInterface
    fun setPanel(on: Boolean): String {
        if (!on) {
            prefs.panelEnabled = false
            FloatingPanelService.stop(a)
            return "OFF"
        }
        if (!a.hasOverlay()) return "NEED_OVERLAY"
        if (!a.hasNotif()) a.runOnUiThread { a.askNotif() }
        prefs.panelEnabled = true
        FloatingPanelService.start(a)
        return "OK"
    }

    @JavascriptInterface fun requestOverlay() = a.runOnUiThread { a.openOverlaySettings() }
    @JavascriptInterface fun requestNotif() = a.runOnUiThread { a.askNotifOrSettings() }
    @JavascriptInterface fun openStorageSettings() = a.runOnUiThread { a.openStorageSettings() }
    @JavascriptInterface fun openAppSettings() = a.runOnUiThread { a.openAppSettings() }

    @JavascriptInterface
    fun loadApps() {
        thread {
            val json = AppRepo.installedJson(a)
            a.js("window.onApps(${JSONObject.quote(json)})")
        }
    }

    @JavascriptInterface
    fun setSlots(json: String) {
        val arr = JSONArray(json)
        prefs.slots = List(arr.length()) { arr.getString(it) }
        FloatingPanelService.refresh(a)
    }

    @JavascriptInterface
    fun cacheBytes(): Long = CleanerHelper.cacheBytes(a)

    @JavascriptInterface
    fun clean(): Long = CleanerHelper.clean(a)

    @JavascriptInterface
    fun openFloating(pkg: String): String {
        if (!prefs.premium) return "PREMIUM"
        return when (val r = FloatingWindowLauncher.launch(a, pkg)) {
            is FloatingWindowLauncher.Result.Failed -> r.message
            else -> "OK"
        }
    }
}

object BuildConfigInfo {
    fun version(a: MainActivity): String =
        try { a.packageManager.getPackageInfo(a.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
}
