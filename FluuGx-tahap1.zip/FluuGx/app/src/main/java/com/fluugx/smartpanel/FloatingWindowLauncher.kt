package com.fluugx.smartpanel

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect

/**
 * Mencoba membuka aplikasi (mis. WhatsApp) dalam jendela mengambang (freeform) milik sistem.
 * Berhasil hanya jika perangkat/ROM mengizinkan freeform. Tidak ada tampilan palsu.
 */
object FloatingWindowLauncher {
    sealed class Result {
        object Launched : Result()
        data class Failed(val message: String) : Result()
    }

    fun launch(ctx: Context, pkg: String): Result {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg)
            ?: return Result.Failed("Aplikasi tidak terpasang.")
        val freeform = ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)
        if (!freeform) return Result.Failed("Jendela mengambang tidak didukung pada perangkat ini.")
        return try {
            val dm = ctx.resources.displayMetrics
            val w = (dm.widthPixels * 0.8f).toInt()
            val h = (dm.heightPixels * 0.55f).toInt()
            val left = (dm.widthPixels - w) / 2
            val top = (dm.heightPixels * 0.15f).toInt()
            val opts = ActivityOptions.makeBasic().setLaunchBounds(Rect(left, top, left + w, top + h))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
            ctx.startActivity(intent, opts.toBundle())
            Result.Launched
        } catch (e: Exception) {
            Result.Failed("Jendela mengambang tidak didukung pada perangkat ini.")
        }
    }
}
