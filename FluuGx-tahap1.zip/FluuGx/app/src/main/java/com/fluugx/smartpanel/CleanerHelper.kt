package com.fluugx.smartpanel

import android.content.Context
import java.io.File

/** Hanya membersihkan cache milik aplikasi Fluu Gx sendiri. Tidak menyentuh aplikasi lain. */
object CleanerHelper {
    private fun dirs(ctx: Context): List<File> =
        listOfNotNull(ctx.cacheDir, ctx.externalCacheDir, ctx.codeCacheDir)

    private fun size(f: File): Long =
        if (f.isFile) f.length() else f.listFiles()?.sumOf { size(it) } ?: 0L

    fun cacheBytes(ctx: Context): Long = dirs(ctx).sumOf { size(it) }

    /** Mengembalikan jumlah byte yang berhasil dibebaskan, atau -1 jika gagal. */
    fun clean(ctx: Context): Long {
        val before = cacheBytes(ctx)
        return try {
            dirs(ctx).forEach { d -> d.listFiles()?.forEach { it.deleteRecursively() } }
            (before - cacheBytes(ctx)).coerceAtLeast(0)
        } catch (e: Exception) { -1 }
    }
}
