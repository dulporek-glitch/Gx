package com.fluugx.smartpanel

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

class FloatingPanelService : Service() {

    companion object {
        const val ACTION_REFRESH = "com.fluugx.smartpanel.REFRESH"
        const val ACTION_STOP = "com.fluugx.smartpanel.STOP"
        private const val CHANNEL = "panel"
        @Volatile var running = false

        fun start(ctx: Context) {
            val i = Intent(ctx, FloatingPanelService::class.java)
            ctx.startForegroundService(i)
        }
        fun refresh(ctx: Context) {
            if (running) ctx.startService(Intent(ctx, FloatingPanelService::class.java).setAction(ACTION_REFRESH))
        }
        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, FloatingPanelService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private var handle: View? = null
    private var panel: View? = null
    private var panelOpen = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            prefs.panelEnabled = false
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground()
        if (!Settings.canDrawOverlays(this)) {
            prefs.panelEnabled = false
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        rebuild()
        return START_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Panel Melayang", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingPanelService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Fluu Gx aktif")
            .setContentText("Panel Melayang sedang berjalan")
            .setContentIntent(open)
            .addAction(0, "Matikan", stop)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, n,
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )
    }

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, overlayType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or (if (prefs.sideRight) Gravity.END else Gravity.START)
        x = 0
        y = prefs.panelY
    }

    private fun rebuild() {
        removeViews()
        panelOpen = false
        addHandle()
    }

    private fun removeViews() {
        handle?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        handle = null; panel = null
    }

    private fun bg(fill: Int, radius: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(fill); cornerRadius = radius.toFloat()
        if (stroke > 0) setStroke(stroke, Color.BLACK)
    }

    // ---------- Gagang di tepi layar (kecil, tidak menutupi layar) ----------
    private fun addHandle() {
        val v = View(this)
        v.background = bg(Color.BLACK, dp(6))
        v.alpha = 0.55f
        val lp = params(dp(10), dp(88))
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f; var downY = 0f; var startY = 0; var dragged = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startY = lp.y; dragged = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    val inward = if (prefs.sideRight) -dx else dx
                    if (!dragged && inward > dp(20) && Math.abs(dy) < Math.abs(dx)) {
                        openPanel(); true
                    } else {
                        if (Math.abs(dy) > slop) dragged = true
                        if (dragged) {
                            lp.y = (startY + dy).toInt().coerceIn(0, resources.displayMetrics.heightPixels - dp(120))
                            runCatching { wm.updateViewLayout(v, lp) }
                        }
                        true
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (dragged) prefs.panelY = lp.y else if (!panelOpen) openPanel()
                    true
                }
                else -> true
            }
        }
        handle = v
        wm.addView(v, lp)
    }

    // ---------- Panel vertikal ----------
    private fun openPanel() {
        if (panelOpen) return
        panelOpen = true
        buzz()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = bg(Color.WHITE, dp(20), dp(2))
            elevation = dp(6).toFloat()
        }
        box.addView(TextView(this).apply {
            text = "X"; setTextColor(Color.GRAY); textSize = 14f
            gravity = Gravity.CENTER
            setOnClickListener { closePanel() }
        }, LinearLayout.LayoutParams(dp(48), dp(26)))

        val slots = prefs.slots
        for (i in 0 until prefs.maxSlots.coerceAtMost(maxOf(slots.size, 5))) {
            val pkg = slots.getOrNull(i)
            val cell = ImageView(this).apply {
                background = bg(Color.WHITE, dp(12), dp(2))
                setPadding(dp(6), dp(6), dp(6), dp(6))
                if (pkg != null) {
                    setImageDrawable(AppRepo.icon(this@FloatingPanelService, pkg))
                    setOnClickListener { openApp(pkg) }
                    setOnLongClickListener { openFloating(pkg); true }
                }
            }
            val lp = LinearLayout.LayoutParams(dp(48), dp(48)).apply { topMargin = dp(6) }
            box.addView(cell, lp)
        }
        box.addView(TextView(this).apply {
            text = "+"; setTextColor(Color.BLACK); textSize = 26f; gravity = Gravity.CENTER
            setOnClickListener {
                closePanel()
                startActivity(
                    Intent(this@FloatingPanelService, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        .putExtra("pick", true)
                )
            }
        }, LinearLayout.LayoutParams(dp(48), dp(44)).apply { topMargin = dp(4) })

        val lp = params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        lp.y = prefs.panelY
        lp.x = dp(4)
        panel = box
        wm.addView(box, lp)
        handle?.visibility = View.INVISIBLE

        if (prefs.animations) {
            val dir = if (prefs.sideRight) 1f else -1f
            box.alpha = 0f; box.scaleX = 0.92f; box.scaleY = 0.92f
            box.post {
                box.translationX = dir * box.width
                box.animate().translationX(0f).alpha(1f).scaleX(1f).scaleY(1f).setDuration(160).start()
            }
        }
    }

    private fun closePanel() {
        val p = panel ?: return
        val finish = {
            runCatching { wm.removeView(p) }
            panel = null; panelOpen = false
            handle?.visibility = View.VISIBLE
        }
        if (prefs.animations) {
            val dir = if (prefs.sideRight) 1f else -1f
            p.animate().translationX(dir * p.width).alpha(0f).setDuration(130)
                .withEndAction { finish() }.start()
        } else finish()
    }

    private fun openApp(pkg: String) {
        closePanel()
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    /** Tekan lama pada slot: coba jendela mengambang (khusus Premium). */
    private fun openFloating(pkg: String) {
        if (!prefs.premium) {
            toast("Jendela mengambang adalah fitur Premium.")
            return
        }
        closePanel()
        when (val r = FloatingWindowLauncher.launch(this, pkg)) {
            is FloatingWindowLauncher.Result.Failed -> toast(r.message)
            else -> {}
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    @Suppress("DEPRECATION")
    private fun buzz() {
        if (!prefs.vibrate) return
        val v = getSystemService(VIBRATOR_SERVICE) as? Vibrator ?: return
        v.vibrate(VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    override fun onDestroy() {
        removeViews()
        running = false
        super.onDestroy()
    }
}
