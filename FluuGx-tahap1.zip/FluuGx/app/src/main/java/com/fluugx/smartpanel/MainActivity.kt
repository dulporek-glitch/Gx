package com.fluugx.smartpanel

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var notifAsked = false

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.apply {
            javaScriptEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            @Suppress("DEPRECATION") allowFileAccessFromFileURLs = false
            @Suppress("DEPRECATION") allowUniversalAccessFromFileURLs = false
            cacheMode = WebSettings.LOAD_NO_CACHE
        }
        web.webViewClient = object : WebViewClient() {
            // Hanya halaman lokal yang boleh dimuat.
            override fun shouldOverrideUrlLoading(v: WebView, r: android.webkit.WebResourceRequest) =
                !r.url.toString().startsWith("file:///android_asset/")
        }
        web.addJavascriptInterface(Bridge(this), "Android")
        web.loadUrl("file:///android_asset/www/index.html")
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra("pick", false) == true) {
            web.postDelayed({ js("window.openPicker && window.openPicker()") }, 400)
        }
    }

    override fun onResume() {
        super.onResume()
        js("window.refresh && window.refresh()")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.onBack && window.onBack())") { r ->
            if (r != "true") @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    fun hasOverlay() = Settings.canDrawOverlays(this)
    fun hasNotif() = Build.VERSION.SDK_INT < 33 ||
        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33 && !hasNotif() && !notifAsked) {
            notifAsked = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }

    fun askNotifOrSettings() {
        if (Build.VERSION.SDK_INT >= 33 && !hasNotif()) {
            if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS) || !notifAsked) {
                notifAsked = true
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
            } else openNotifSettings()
        } else openNotifSettings()
    }

    private fun openNotifSettings() = startActivity(
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
    )

    fun openOverlaySettings() = startActivity(
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
    )

    fun openAppSettings() = startActivity(
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
    )

    fun openStorageSettings() {
        try { startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) }
        catch (e: Exception) { openAppSettings() }
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        js("window.refresh && window.refresh()")
    }
}
